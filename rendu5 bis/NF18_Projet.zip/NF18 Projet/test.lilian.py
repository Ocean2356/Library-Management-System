from datetime import date

date = datetime.date(1998, 1, 7)